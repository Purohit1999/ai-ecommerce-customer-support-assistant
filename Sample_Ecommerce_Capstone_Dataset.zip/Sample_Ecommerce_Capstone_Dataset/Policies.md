# Policies (Sample Dataset)

This is a **sample dataset** policy document for an e-commerce support assistant capstone.

---

## 1. Shipping Policy
- Free standard shipping above ₹999.
- Flat ₹79 fee below ₹999.
- Standard delivery: 3–6 business days (remote locations may take longer).
- Orders processed Monday–Saturday (excluding public holidays).

---

## 2. Returns & Refunds Policy
- Most products are returnable within 7 days of delivery.
- Items must be unused and returned with accessories and packaging.
- Refunds are processed after quality check; typical timelines: 3–7 business days.

Non-returnable examples:
- Hygiene/personal care items
- Software licenses and digital subscriptions
- Items explicitly marked as non-returnable

---

## 3. Cancellation Policy
- Cancellations allowed until shipment.
- After shipment, cancellation is not supported; eligible items can be returned after delivery.

---

## 4. Warranty Policy
- Most electronics include a manufacturer warranty of 6–24 months.
- Warranty claims may require invoice and product identifiers (serial/IMEI).

---

## 5. Payment & Security
- Secure payments via PCI-DSS compliant gateways and encryption.
- Methods: cards, net banking, UPI, wallets; COD for eligible pin codes/products.
- Failed payment reversals typically occur within 3–7 business days.

---

## 6. Privacy
- Personal data is used only for order fulfilment and service improvement.
- Data may be shared with logistics/payment partners as required for fulfilment.

---

## 7. Support
- Email: support@example.com
